make clean
make build-amd64
