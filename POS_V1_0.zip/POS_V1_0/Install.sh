sudo apt-get update && sudo apt-get install -y docker
docker build buildenv -t pos
