#include "math.h"
#include "string.h"
#include "print.h"
int ttp(int num, int power){
    int64_t a = num;
    power = power -1;
    for(int i = 0; i < power ; i++){
        a *= num;
    }
    return a/10;
}
double fabs(double x) {
  if (x < 0) {
    return -x;
  } else {
    return x;
  }
}

int is_int(double value) {
  // Check if the value is a whole number.
  int is_whole_number = floor(value) == value;

  // Check if the value is less than the maximum value of an int.
  int is_less_than_max_int = value < 2147483647;

  // Check if the value is greater than the minimum value of an int.
  int is_greater_than_min_int = value >  -2147483648;

  // Return true if all three conditions are met.
  return is_whole_number && is_less_than_max_int && is_greater_than_min_int;
}

int floor(double x) {
  /* Check if the input number is negative. */
  if (x < 0) {
    /* If it is, then return the negative of the largest integer less than or equal to the absolute value of x, plus 1. */
    return -(int)(fabs(x) + 1);
  } else {
    /* Otherwise, simply return the largest integer less than or equal to x. */
    return (int)x;
  }
}
int math(int num, char* type, int num2){
    if(str_compare("-s", type) == 0){
        int64_t a = num - num2;
        return a;
    }
    if(str_compare("-a", type) == 0){
        int64_t a = num + num2;
        return a;
    }
    if(str_compare("-d", type) == 0){
        int64_t a = num / num2;
        return a;
    }
    if(str_compare("-m", type) == 0){
        int64_t a = num * num2;
        return a;
    }
    if(str_compare("-p", type) == 0){
        int64_t a = ttp(num, num2+1);
        return a;
    }

}
double dpow(double base, int exponent) {
  double result = 1;
  for (int i = 0; i < exponent; i++) {
    result *= base;
  }
  return result;
}