#include "string.h"
#include <stddef.h>

int str_compare(const char* str1, const char* str2) {
    while (*str1 && *str2 && *str1 == *str2) {
        str1++;
        str2++;
    }

    if (*str1 == '\0' && *str2 == '\0') {
        return 0;  // Strings are equal
    } else if (*str1 < *str2) {
        return -1; // str1 is less than str2
    } else {
        return 1;  // str1 is greater than str2
    }
}

int str_length(const char* str) {
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

void str_concat(char* dest, const char* src) {
    int dest_len = str_length(dest);
    int i = 0;
    while (src[i] != '\0') {
        dest[dest_len + i] = src[i];
        i++;
    }
    dest[dest_len + i] = '\0';
}

char* str_token(char* str, const char* delim) {
    static char* buffer = NULL;
    if (str != NULL) {
        buffer = str;
    }

    if (buffer == NULL || *buffer == '\0') {
        return NULL;
    }

    // Skip leading delimiters
    while (*buffer != '\0' && is_whitespace(*buffer)) {
        buffer++;
    }

    if (*buffer == '\0') {
        return NULL;
    }

    char* token = buffer;
    while (*buffer != '\0' && !is_whitespace(*buffer)) {
        buffer++;
    }

    if (*buffer != '\0') {
        *buffer = '\0';
        buffer++;
    }

    return token;
}

char* strncpy(char* dest, const char* src, size_t n) {
    char* d = dest;
    const char* s = src;
    while (n > 0 && *s != '\0') {
        *d++ = *s++;
        n--;
    }
    while (n > 0) {
        *d++ = '\0';
        n--;
    }
    return dest;
}

void* memcpy(void* dest, const void* src, size_t n) {
    char* d = (char*)dest;
    const char* s = (const char*)src;
    for (size_t i = 0; i < n; i++) {
        d[i] = s[i];
    }
    return dest;
}

// This function fills the memory with the specified value.
void* memset(void* dest, int c, size_t n) {
    char* d = (char*)dest;
    for (size_t i = 0; i < n; i++) {
        d[i] = c;
    }
    return dest;
}

char *strcpy(char *dest, const char *src) {
  char *p = dest;
  while (*src != '\0') {
    *p++ = *src++;
  }
  *p = '\0';
  return dest;
}
