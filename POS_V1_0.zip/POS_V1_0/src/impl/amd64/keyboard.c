#include "keyboard.h"

#include "keyboard.h"

int shift = 0;
int caps_lock = 0;

static const char keymap[256] = {
    0x00,  0x0e,  '1',  '2',     /* 0x00 */
     '3',  '4',  '5',  '6',     /* 0x04 */
     '7',  '8',  '9',  '0',     /* 0x08 */
     '-',  '=',   '\b', '\t',     /* 0x0C */
     'q',  'w',  'e',  'r',     /* 0x10 */
     't',  'y',  'u',  'i',     /* 0x14 */
     'o',  'p',  '[',  ']',     /* 0x18 */
    '\n', 0x00,  'a',  's',     /* 0x1C */
     'd',  'f',  'g',  'h',     /* 0x20 */
     'j',  'k',  'l',  ';',     /* 0x24 */
    '\'',  '`', 0x00, '\\',     /* 0x28 */
     'z',  'x',  'c',  'v',     /* 0x2C */
     'b',  'n',  'm',  ',',     /* 0x30 */
     '.',  '/', 0x00,  '*',     /* 0x34 */
    0x00,  ' ', 0x00, 0x00,     /* 0x38 */
    0x00, 0x00, 0x00, 0x00,     /* 0x3C */
    0x00, 0x00, 0x00, 0x00,     /* 0x40 */
    0x00, 0x00, 0x00,  '7',     /* 0x44 */
     '8',  '9',  '-',  '4',     /* 0x48 */
     '5',  '6',  '+',  '1',     /* 0x4C */
     '2',  '3',  '0',  '.',     /* 0x50 */
    0x00, 0x00, 0x00, 0x00,     /* 0x54 */
    0x00, 0x00, 0x00, 0x00      /* 0x58 */
};

char read_key() {
    char scancode;

    while (1) {
        // Wait for the keyboard status port to be ready
        while ((inb(KEYBOARD_STATUS_PORT) & 0x01) == 0);

        // Read the scancode from the data port
        scancode = inb(KEYBOARD_DATA_PORT);

        // Check if the top bit of the scancode is set (key release)
        if (scancode & 0x80) {
            // Ignore key releases
            continue;
        }

        // If the character is the shift key,
        if (scancode == ':' + 's' + '/') {
            // Set the shift state.
            shift = 1;
            break;
        }

        // If the character is the caps lock key,
        if (scancode == ':' + 'c' + '/') {
            // Toggle the caps lock state.
            caps_lock ^= 1;
            break;
        }

        // Convert scancode to ASCII character
        char c = keymap[scancode];

        // If the caps lock is on,
        if (caps_lock) {
            // Convert lowercase letters to uppercase.
            if (c >= 'a' && c <= 'z') {
                c -= 'a' - 'A';
            }
        } else if (shift) {
            // Convert uppercase letters to lowercase.
            if (c >= 'A' && c <= 'Z') {
                c += 'a' - 'A';
            }
        }

        return c;
    }
}

int is_whitespace(char c) {
    return (c == ' ' || c == '\t' || c == '\n' || c == '\r');
}

void read_str(char* buffer) {
    int index = 0;
    while (1) {
        char key = read_key();

        if (key == '\n') {
            buffer[index] = '\0';
            break;
        } else if (key == '\b') {
            if (index > 0) {
                buffer[--index] = '\0';
                print_char('\b');
            }
        }else if(key == ':'+'s'+'/'){
            buffer[index]='\0';
            break;
        }else if(key == ':'+'c'+'/'){
            buffer[index]='\0';
            break;
        }else {
            buffer[index++] = key;
            print_char(key);
        }
    }
}