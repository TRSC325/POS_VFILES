#include "authi.h"


UserInfo *user;

char* get_username(){
    return user->username;
}
void set_username(char* val){
    user->username = val;
}
char* get_password(){
    return user->password;
}
void set_password(char* val){
    user->password = val;
}