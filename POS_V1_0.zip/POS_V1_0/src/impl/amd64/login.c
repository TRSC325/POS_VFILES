#include "print.h"
#include "string.h"
#include "login.h"
#include "authi.h"

int log = 0;

void display_login_screen() {
    // Print the login prompt

    // Get the username
    char username[MAX_USERNAME_LENGTH + 1]; // +1 for null-terminator
    print_newline();
    print_str("Username: ");
    read_str(username, MAX_USERNAME_LENGTH);

    // Get the password
    char password[MAX_PASSWORD_LENGTH + 1]; // +1 for null-terminator
    print_newline();
    print_str("Password: ");
    read_str(password, MAX_PASSWORD_LENGTH);

    // Perform authentication logic here
    // You can compare the entered username and password
    // with a predefined set of credentials or any other
    // authentication mechanism you want to implement

    // Placeholder authentication logic (accept any username and password)
    if (str_compare(username, get_username()) == 0 && str_compare(password, get_password()) == 0) {
        print_newline();
        print_str("Authentication successful. Welcome, ");
        print_str(username);
        print_newline();
        log = 1;
    } else {
        print_str("Authentication failed. Invalid username or password.\n");
    }
}

void start_os() {
    print_clear();
    // Display the login screen
    display_login_screen();

    if (log == 1) {
        print_set_color(PRINT_COLOR_LIGHT_GRAY, PRINT_COLOR_BLACK);
        print_newline();
        print_str("Welcome ");
        print_str(get_username());
        print_newline();
    } else {
        print_set_color(PRINT_COLOR_RED, PRINT_COLOR_BLACK);
        print_newline();
        print_str("Authentication failed. Exiting the OS.\n");
        print_newline();
    }
    print_clear();
}

int set_log(int val){
    log = val;
}

int get_auth() {
    return log;
}
