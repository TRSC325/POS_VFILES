#include "setup.h"
#include "print.h"
#include "keyboard.h"
#include "string.h"
#include "authi.h"
int page=0;
int l = 1;
char* b[100];
char* username[1000];
char* password[1000];
char* style;
void display_setup(){
    while(1){
        if(page == 0){
                print_newline();
                print_str("Setup OS");
                print_newline();
                print_newline();
                print_str("Language:");
                print_newline();
                print_newline();
                print_str("english: 0\tespañol: 1\tDeutsch: 2");
                print_newline();
                print_newline();
                print_str("option: ");
                while(1){
                   read_str(b);
                   break;
                }
                print_clear();
                page = 1;
                l = 1;
            }
         if(page = 1){
            print_newline();
            print_str("Setup OS");
            print_newline();
            print_str(b);
            print_newline();
            print_str("Style:");
            print_newline();
            print_newline();
            print_str("classic: 0\tcustom: 1");
            print_newline();
            print_newline();
            print_str("option: ");
            while(1){
                read_str(b);
                break;
            }
            print_clear();
            page = 2;
            l = 1;
         }
         if(page = 1){
            print_newline();
            print_str("Setup OS");
            print_newline();
            print_newline();
            print_str("Register");
            print_newline();
            print_newline();
            print_str("Username: ");
            while(1){
                read_str(username);
                print_newline();
                print_str("Password: ");
                read_str(password);
                break;
            }

            char* user[str_length(username)];
            char* pass[str_length(password)];
            for(int i = 0; i < str_length(username); i++){
                user[i] = username[i];
            }
            for(int i = 0; i < str_length(password); i++){
                pass[i] = password[i];
            }

            set_username(user);
            set_password(pass);

            print_clear();
            page = 3;
            l = 1;
            break;
         }
    }
}
