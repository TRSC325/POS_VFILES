#include "print.h"
#include "string.h"

const static size_t NUM_COLS = 80;
const static size_t NUM_ROWS = 25;

struct Char {
    uint8_t character;
    uint8_t color;
};

struct Char* buffer = (struct Char*) 0xb8000;
size_t col = 0;
size_t row = 0;
uint8_t color = PRINT_COLOR_WHITE | (PRINT_COLOR_BLACK << 4);

int get_print_buffer_length(){
    return str_length(buffer);
}

void clear_row(size_t row) {
    struct Char empty = (struct Char) {
        .character = ' ',
        .color = color,
    };

    for (size_t col = 0; col < NUM_COLS; col++) {
        buffer[col + NUM_COLS * row] = empty;
    }
}

void print_clear() {

    struct Char empty = (struct Char) {
        .character = ' ',
        .color = color,
    };

    for(int i = 0; i < NUM_COLS; i++){
       for(int j = 0; j <NUM_ROWS; j++){
        buffer[i + NUM_COLS * j] = empty;
       }
    }
    col = 0;
    row = 0;
}

void print_newline() {
    col = 0;

    if (row < NUM_ROWS - 1) {
        row++;
        return;
    }

    for (size_t row = 1; row < NUM_ROWS; row++) {
        for (size_t col = 0; col < NUM_COLS; col++) {
            struct Char character = buffer[col + NUM_COLS * row];
            buffer[col + NUM_COLS * (row - 1)] = character;
        }
    }

    clear_row(NUM_ROWS - 1);
}

void print_char(char character) {
    if (character == '\n') {
        print_newline();
        return;
    }

    if (character == '\t') {
        // Handle tab by printing spaces until reaching the next tab stop
        const size_t tab_width = 4;
        size_t remaining_spaces = tab_width - (col % tab_width);
        while (remaining_spaces > 0) {
            buffer[col + NUM_COLS * row] = (struct Char) {
                character: ' ',
                color: color,
            };
            col++;
            remaining_spaces--;
        }
        return;
    }

    if (character == '\b') {
        // Handle backspace by deleting the previous character
        if (col > 0) {
            col--;
            buffer[col + NUM_COLS * row] = (struct Char) {
                character: ' ',
                color: color,
            };
        }
        return;
    }

    if(character == ':'+'s'+'/'){
        buffer[col + NUM_COLS * row] = (struct Char) {
                character: ' ',
                color: color,
        };
        return;
    }

    if (col >= NUM_COLS) {
        print_newline();
    }

    buffer[col + NUM_COLS * row] = (struct Char) {
        character: (uint8_t) character,
        color: color,
    };

    col++;
}


void print_str(char* str) {
    for (size_t i = 0; str[i] != '\0'; i++) {
        print_char(str[i]);
    }
}

void print_set_color(uint8_t foreground, uint8_t background) {
    color = foreground + (background << 4);
}
char number_to_char(int number) {
    if(number < 0){
        number = -number;
    }
  // Check if the number is between 0 and 9.
  if ((number >= 0 && number <= 9)) {
    // Return the character corresponding to the number.
    return (char) (number + '0');
  } else {
    // Return the character '\0'.
    return '\0';
  }
}
void print_int(int value) {
  // Create a char buffer to store the digits of the number.
  char buffer[10000];

  // Initialize the index of the buffer.
  int i = 0;

  // Iterate while the value is not 0.
  while (value != 0) {
    // Get the digit at the units place.
    int digit = value % 10;

    // Store the digit in the buffer.
    if(value >= 0){
        buffer[i++] = number_to_char(digit);
    }else{
        buffer[0] = "-";
        if(i != 0){
            buffer[i++] = number_to_char(digit);
        }
    }

    // Divide the value by 10 to get the next digit.
    value /= 10;
  }

  // Print the number in reverse order.
  for (int j = i - 1; j >= 0; j--) {
    // Print the digit at the jth index.
    print_char(buffer[j]);
  }
}
void print_double(double value) {
  // Create a char buffer to store the digits of the number.
  char buffer[10000];

  // Initialize the index of the buffer.
  int i = 0;

  // Check if the value is negative.
  if (value < 0) {
    // Store a '-' character in the buffer.
    buffer[i++] = '-';

    // Make the value positive.
    value = -value;
  }

  // Iterate while the value is not 0.
  while (value != 0) {
    // Get the digit at the units place.
    int digit = (int)value % 10;

    // Store the digit in the buffer.
    buffer[i++] = number_to_char(digit);

    // Divide the value by 10 to get the next digit.
    value /= 10;
  }

  // Print the number in reverse order.
  for (int j = i - 1; j >= 0; j--) {
    // Print the digit at the jth index.
    print_char(buffer[j]);
  }
}

