#include "commands.h"
#include "print.h"
#include "string.h"
#include "authi.h"
#include "login.h"
int run = 1;
int logi = 1;
void clear_screen() {
    // Clear the entire screen
   print_clear();
}

int char_to_number(char* character) {
    int num = 0;
    for(int i = 0; i < str_length(character); i++){
      // Check if the character is a digit.
      if(character[0] != '-'){
          if (character[i] >= '0' && character[i] <= '9') {
            // Return the number corresponding to the character.
            num +=  (character[i] - '0')*ttp(10,str_length(character)-i);
          } else {
            // Return -1.
            return 0;
          }
      }else{
          if(i != 0){
              if (character[i] >= '0' && character[i] <= '9') {
                num -=  (character[i] - '0')*ttp(10,str_length(character)-i);
              } else {
                // Return -1.
                return 0;
              }
          }
      }
    }
  return num;
}



void execute_command(const char* command) {
    char command_copy[100];
    int i = 0;
    while (command[i] != '\0') {
        command_copy[i] = command[i];
        i++;
    }

    command_copy[i] = '\0';

    // Split the command from spaces but not within quotes
    char* token = str_token(command_copy, " ");
    char* arguments[100];  // Maximum 10 arguments
    int arg_count = 0;
    int in_quotes = 0;

    for (int i = 0; i < arg_count; i++) {
            arguments[i] = NULL;
     }

    while (token != NULL) {
        if (token[0] == '\"' && token[str_length(token) - 1] == '\"') {
            // Token is within quotes, remove the quotes and add as an argument
            token++;
            token[str_length(token) - 1] = '\0';
            arguments[arg_count++] = token;
        } else if (token[0] == '\"') {
            // Token starts with a quote, set in_quotes flag
            in_quotes = 1;
            arguments[arg_count] = token + 1;
        } else if (token[str_length(token) - 1] == '\"') {
            // Token ends with a quote, add as an argument and clear in_quotes flag
            token[str_length(token) - 1] = '\0';
            arguments[arg_count++] = token;
            in_quotes = 0;
        } else if (in_quotes) {
            // Token is within quotes, add to the current argument
            str_concat(arguments[arg_count], " ");
            str_concat(arguments[arg_count], token);
        } else {
            // Token is outside quotes, add as a separate argument
            arguments[arg_count++] = token;
        }

        token = str_token(NULL, " ");
    }

    if (str_compare(arguments[0], "echo") == 0) {
        if (arg_count >= 2) {
            for (int i = 1; i < arg_count; i++) {
                print_newline();
                print_str(arguments[i]);
                if (i < arg_count - 1) {
                    print_char(' ');
                }
                print_newline();
            }
            print_newline();
            for (int i = 0; i < arg_count; i++) {
                arguments[i] = NULL;
            }
        } else {
            print_newline();
            print_str("Usage: echo [message]");
            print_newline();
        }
        for(int i = 0; i <= str_length(arguments); i++){
        arguments[i] = NULL;
    }
    } else if (str_compare(arguments[0], "help") == 0) {
        print_newline();
        if (arguments[1] == NULL) {
            print_str("echo [message]");
            print_newline();
            print_str("help [command]");
            print_newline();
            print_str("clear");
        } else {
            if (str_compare(arguments[1], "echo") == 0) {
                print_str("echo [message]");
                print_newline();
                print_str("example: echo 'Hello World!'");
            } else if (str_compare(arguments[1], "help") == 0) {
                print_str("help [command]");
                print_newline();
                print_str("example: help echo");
            }else {
                print_set_color(PRINT_COLOR_RED, PRINT_COLOR_BLACK);
                print_str("Error command not found: ");
                print_str(arguments[1]);
                print_set_color(PRINT_COLOR_WHITE, PRINT_COLOR_BLACK);
            }
        }
        print_newline();
        for (int i = 0; i < arg_count; i++) {
            arguments[i] = NULL;
        }
    } else if (str_compare(arguments[0], "version") == 0) {
        print_newline();
        print_str("v1.0");
        print_newline();
        for (int i = 0; i < arg_count; i++) {
            arguments[i] = NULL;
        }
    } else if(str_compare(arguments[0], "reboot") == 0){
        print_newline();
        print_str("The reboot command dose not work write now.");
        print_newline();
        for (int i = 0; i < arg_count; i++) {
            arguments[i] = NULL;
        }
    } else if(str_compare(arguments[0], "set") == 0){
        if(str_compare(arguments[1], "username") == 0){
            set_username(arguments[2]);
            print_newline();
            for (int i = 0; i < arg_count; i++) {
                arguments[i] = NULL;
            }
        }else if(str_compare(arguments[1], "password") == 0){
            set_password(arguments[2]);
            print_newline();
            for (int i = 0; i < arg_count; i++) {
                arguments[i] = NULL;
            }
        }else{
            print_newline();
            print_str("username=");
            print_str(get_username());
            print_newline();
            print_str("password=");
            print_str(get_password());
            print_newline();
            for (int i = 0; i < arg_count; i++) {
                arguments[i] = NULL;
            }
        }
        for (int i = 0; i < arg_count; i++) {
            arguments[i] = NULL;
        }
    }else if(str_compare(arguments[0], "logout") == 0) {
        logi = 0;
        set_log(logi);
        for (int i = 0; i < arg_count; i++) {
            arguments[i] = NULL;
        }
    } else if(str_compare(arguments[0], "clear") == 0){
        clear_screen();
    } else if(str_compare(arguments[0], "math") == 0){
        int PI = 3.145;
        int a = math(char_to_number(arguments[1]), arguments[2], char_to_number(arguments[3]));
        print_newline();
        print_int(a);
        print_newline();
    }else {
        print_newline();
        print_set_color(PRINT_COLOR_RED, PRINT_COLOR_BLACK);
        print_str("Invalid command: ");
        print_str(arguments[0]);
        print_set_color(PRINT_COLOR_WHITE, PRINT_COLOR_BLACK);
        print_newline();
        for (int i = 0; i < arg_count; i++) {
            arguments[i] = NULL;
        }
    }
    for (int i = 0; i < arg_count; i++) {
        arguments[i] = NULL;
    }
}

int get_run(){
    return run;
}

void set_logi(int val){
    logi = val;
}
int get_logi(){
    return logi;
}