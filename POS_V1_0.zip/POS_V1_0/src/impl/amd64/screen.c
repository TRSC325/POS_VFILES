#include "screen.h"

void screen_init(struct screen *screen, uint8_t *buffer, uint16_t width, uint16_t height) {
    screen->buffer = buffer;
    screen->width = width;
    screen->height = height;
}

void screen_putpixel(struct screen *screen, uint16_t x, uint16_t y, uint8_t color) {
    uint16_t index = y * screen->width + x;
    screen->buffer[index] = color;
}
