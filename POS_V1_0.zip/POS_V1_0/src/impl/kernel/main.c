#include "print.h"
#include "string.h"
#include "commands.h"
#include "login.h"
#include "authi.h"
#include "setup.h"

#define KEYBOARD_STATUS_PORT 0x64
#define KEYBOARD_DATA_PORT 0x60

char inb(unsigned short port) {
    char value;
    __asm__ volatile("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

int kernel_main() {
    int key;
    int set = 0;
    while (1) {
        if(set){
        int log = get_auth();
        if(log){
            print_set_color(PRINT_COLOR_GREEN, PRINT_COLOR_BLACK);
            print_str("$POS/");
            print_str(get_username());
            print_str("> ");
            char command[100];
            read_str(command);

            execute_command(command);
            if(str_compare(command, "reboot") == 0){
                break;
            }
        }else{
            start_os();
        }
        }else{
            display_setup();
            set = 1;
        }
    }
    
    return 0;
}
