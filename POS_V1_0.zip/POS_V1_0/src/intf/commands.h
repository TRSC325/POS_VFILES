#ifndef COMMANDS_H
#define COMMANDS_H
#include "authi.h"
void clear_screen();
void execute_command(const char* command);
int get_run();
void set_logi(int val);
int get_logi();
#endif