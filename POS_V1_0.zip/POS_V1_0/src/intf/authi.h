#ifndef AUTHI_H
#define AUTHI_H

typedef struct userinfo{
    char* username;
    char* password;
} UserInfo;

char* get_username();
void set_username(char* val);
char* get_password();
void set_password(char* val);
#endif