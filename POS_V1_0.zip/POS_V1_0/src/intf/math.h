#ifndef AUTHI_H
#define AUTHI_H
int ttp(int num, int power);
double fabs(double x);
int is_int(double value);
int floor(double x);
int math(int num, char* type, int num2);
double dpow(double base, int exponent);
#endif