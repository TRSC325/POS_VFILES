#ifndef KEYBOARD_H
#define KEYBOARD_H
#define KEYBOARD_STATUS_PORT 0x64
#define KEYBOARD_DATA_PORT 0x60
char read_key();
int is_whitespace(char c);
void read_str(char* buffer);
#endif