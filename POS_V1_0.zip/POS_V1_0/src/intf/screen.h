#ifndef SCREEN_H
#define SCREEN_H

#include <stdint.h>

struct screen {
    uint8_t *buffer;
    uint16_t width;
    uint16_t height;
};

void screen_init(struct screen *screen, uint8_t *buffer, uint16_t width, uint16_t height);
void screen_putpixel(struct screen *screen, uint16_t x, uint16_t y, uint8_t color);

#endif
