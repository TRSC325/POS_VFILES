#ifndef STRING_H
#define STRING_H
#include "stddef.h"
int str_compare(const char* str1, const char* str2);
int str_length(const char* str);
void str_concat(char* dest, const char* src);
char* str_token(char* str, const char* delim);
char* strncpy(char* dest, const char* src, size_t n);
void* memcpy(void* dest, const void* src, size_t n);
void* memset(void* dest, int c, size_t n);
char *strcpy(char *dest, const char *src);
#endif