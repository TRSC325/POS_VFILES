#ifndef LOGIN_H
#define LOGIN_H
#include "authi.h"

#define MAX_USERNAME_LENGTH 20
#define MAX_PASSWORD_LENGTH 20
void display_login_screen();
void start_os();
int set_log(int val);
int get_auth();

#endif