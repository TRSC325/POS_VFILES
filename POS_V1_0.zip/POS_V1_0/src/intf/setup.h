#ifndef SETUP_H
#define SETUP_H
void display_setup();
#endif